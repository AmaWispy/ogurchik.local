<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\PageController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::group([
    'prefix' => 'artisan',
    'middleware' => ['auth'],
], function () {
    Route::get('optimize-clear', function() {
        Artisan::call('optimize:clear');
        return 'Application cache has been cleared';
    });
    Route::get('storage-link', function() {
        try {
            Artisan::call('storage:link --relative');
            return 'Symlink успешно создан!';
        } catch (\Exception $e) {
            return 'Ошибка: ' . $e->getMessage();
        }
    });
    Route::get('/storage-link-standard', function () {
        // Стандартная структура Laravel, где public внутри проекта
        $target = base_path('storage/app/public');
        $link = public_path('storage');
        
        // Удаляем файл storage, если он уже существует
        if (file_exists($link) && !is_dir($link) && !is_link($link)) {
            unlink($link);
        }
        
        // Показываем информацию о путях
        echo "Target path: $target<br>";
        echo "Link path: $link<br>";
        
        // Проверяем существование исходной папки
        if (!file_exists($target)) {
            return "Ошибка: папка-источник ($target) не существует!";
        }
        
        try {
            // Стандартная команда artisan
            Artisan::call('storage:link');
            return "Symlink успешно создан!<br>$target -> $link";
        } catch (\Exception $e) {
            // Если artisan не сработал, пробуем прямой symlink
            try {
                symlink($target, $link);
                return "Symlink создан вручную!<br>$target -> $link";
            } catch (\Exception $e2) {
                return "Ошибки:<br>1. " . $e->getMessage() . "<br>2. " . $e2->getMessage();
            }
        }
    });
    
    Route::get('/storage-link-symfony', function () {
        $filesystem = new Filesystem();
        
        $target = base_path('storage/app/public');
        $link = public_path('storage');
        
        echo "Target path: $target<br>";
        echo "Link path: $link<br>";
        
        // Проверяем существование исходной папки
        if (!file_exists($target)) {
            return "Ошибка: папка-источник ($target) не существует!";
        }
        
        // Удаляем файл storage, если он существует и не симлинк
        if (file_exists($link) && !is_link($link)) {
            if (is_dir($link)) {
                $filesystem->remove($link);
            } else {
                unlink($link);
            }
        }
        
        try {
            // Создаем симлинк с помощью Symfony Filesystem
            $filesystem->symlink($target, $link);
            return "Symlink успешно создан с помощью Symfony Filesystem!<br>$target -> $link";
        } catch (IOExceptionInterface $e) {
            return "Ошибка: " . $e->getMessage();
        }
    });
});

Route::get('/', [HomeController::class, 'index'])->name('home');

Route::get('/pages/check-non-standard', [PageController::class, 'findNonStandardCharacters'])->name('pages.check-non-standard');


// Маршрут для страниц
Route::get('/pages/{page:slug}', [PageController::class, 'show'])->name('pages.show');

Route::get('/new', [PageController::class, 'new'])->name('new');
Route::get('/random', [PageController::class, 'random'])->name('random');
Route::get('/search', [PageController::class, 'search'])->name('search');
